package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.BtthHeavenlyFlames;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Item;

public class ModItems {
    public static final Item GREEN_LOTUS_CORE_FLAME = register("green_lotus_core_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 3, "green_lotus", "§aGreen Lotus Core Flame"));
    public static final Item FALLEN_HEART_FLAME = register("fallen_heart_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 5, "fallen_heart", "§dFallen Heart Flame"));
    public static final Item SEA_HEART_FLAME = register("sea_heart_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 4, "sea_heart", "§bSea Heart Flame"));
    public static final Item BONE_CHILLING_FLAME = register("bone_chilling_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 6, "bone_chilling", "§3Bone Chilling Flame"));
    public static final Item NINE_DRAGON_LIGHTNING_FLAME = register("nine_dragon_lightning_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 7, "nine_dragon", "§5Nine Dragon Lightning Flame"));
    public static final Item THREE_THOUSAND_BURNING_FLAME = register("three_thousand_burning_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 8, "three_thousand", "§6Three Thousand Burning Flame"));
    public static final Item GOLD_EMPEROR_INCINERATING_FLAME = register("gold_emperor_incinerating_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 10, "gold_emperor", "§eGold Emperor Incinerating Flame"));
    public static final Item PURIFYING_DEMONIC_LOTUS_FLAME = register("purifying_demonic_lotus_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 11, "purifying_lotus", "§5Purifying Demonic Lotus Flame"));
    public static final Item NIHILITY_DEVOURING_FLAME = register("nihility_devouring_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(16), 12, "nihility", "§8Nihility Devouring Flame"));

    public static final Item FLAME_REFINING_ALTAR = register("flame_refining_altar",
            new Item(new FabricItemSettings().maxCount(8)));
    public static final Item HEAVENLY_FLAME_ESSENCE = register("heavenly_flame_essence",
            new Item(new FabricItemSettings().maxCount(64)));

    public static final Item FLAME_HELMET = register("flame_helmet",
            new ArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.HELMET, new FabricItemSettings()));
    public static final Item FLAME_CHESTPLATE = register("flame_chestplate",
            new ArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.CHESTPLATE, new FabricItemSettings()));
    public static final Item FLAME_LEGGINGS = register("flame_leggings",
            new ArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.LEGGINGS, new FabricItemSettings()));
    public static final Item FLAME_BOOTS = register("flame_boots",
            new ArmorItem(ArmorMaterials.NETHERITE, ArmorItem.Type.BOOTS, new FabricItemSettings()));

    public static final Item XIAO_CLAN_CREST = register("xiao_clan_crest", new Item(new FabricItemSettings().maxCount(1)));
    public static final Item JIA_NAN_ACADEMY_CREST = register("jia_nan_academy_crest", new Item(new FabricItemSettings().maxCount(1)));
    public static final Item YUN_LAN_SECT_CREST = register("yun_lan_sect_crest", new Item(new FabricItemSettings().maxCount(1)));
    public static final Item MITRE_CLAN_CREST = register("mitre_clan_crest", new Item(new FabricItemSettings().maxCount(1)));

    // Back Ring item — right click to reroll random ring style
    public static final Item HEAVENLY_BACK_RING = register("heavenly_back_ring",
            new BackRingItem(new FabricItemSettings().maxCount(1)));

    private static Item register(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(BtthHeavenlyFlames.MOD_ID, name), item);
    }

    public static void register() {
        // static init does registration
        BtthHeavenlyFlames.LOGGER.info("Registered Heavenly Flame items");
    }
}
