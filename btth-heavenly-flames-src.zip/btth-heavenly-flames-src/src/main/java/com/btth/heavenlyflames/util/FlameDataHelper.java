package com.btth.heavenlyflames.util;

import com.btth.heavenlyflames.component.PlayerFlameData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public class FlameDataHelper {
    private static final String KEY = "BtthHeavenlyFlamesData";

    public static PlayerFlameData get(Player player) {
        PlayerFlameData data = new PlayerFlameData();
        CompoundTag persistent = player.getPersistentData();
        if (persistent.contains(KEY)) {
            data.load(persistent.getCompound(KEY));
        }
        return data;
    }

    public static void set(Player player, PlayerFlameData data) {
        player.getPersistentData().put(KEY, data.save());
    }
}
