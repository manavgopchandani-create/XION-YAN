package com.btth.heavenlyflames.util;

import com.btth.heavenlyflames.component.PlayerFlameData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.storage.LevelResource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores cultivation / flame data per player.
 * Cache + NBT file under the world folder (works with Mojang mappings).
 */
public class FlameDataHelper {
    private static final Map<UUID, PlayerFlameData> CACHE = new ConcurrentHashMap<>();
    private static final String FOLDER = "btth_heavenly_flames";

    public static PlayerFlameData get(Player player) {
        return CACHE.computeIfAbsent(player.getUUID(), uuid -> {
            PlayerFlameData data = new PlayerFlameData();
            if (player instanceof ServerPlayer serverPlayer) {
                loadFromDisk(serverPlayer, data);
            }
            return data;
        });
    }

    public static void set(Player player, PlayerFlameData data) {
        CACHE.put(player.getUUID(), data);
        if (player instanceof ServerPlayer serverPlayer) {
            saveToDisk(serverPlayer, data);
        }
    }

    private static File getPlayerFile(ServerPlayer player) {
        MinecraftServer server = player.server;
        File root = server.getWorldPath(LevelResource.ROOT).toFile();
        File dir = new File(root, FOLDER);
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, player.getUUID() + ".dat");
    }

    private static void loadFromDisk(ServerPlayer player, PlayerFlameData data) {
        File file = getPlayerFile(player);
        if (!file.exists()) return;
        try (FileInputStream in = new FileInputStream(file)) {
            CompoundTag tag = NbtIo.readCompressed(in);
            if (tag != null) data.load(tag);
        } catch (Exception ignored) {
        }
    }

    private static void saveToDisk(ServerPlayer player, PlayerFlameData data) {
        File file = getPlayerFile(player);
        try (FileOutputStream out = new FileOutputStream(file)) {
            NbtIo.writeCompressed(data.save(), out);
        } catch (Exception ignored) {
        }
    }

    public static void unload(UUID uuid) {
        CACHE.remove(uuid);
    }
}
