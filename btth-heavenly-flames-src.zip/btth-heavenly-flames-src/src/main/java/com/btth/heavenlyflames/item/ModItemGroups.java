package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.BtthHeavenlyFlames;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class ModItemGroups {
    public static final CreativeModeTab MAIN = Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB,
            new ResourceLocation(BtthHeavenlyFlames.MOD_ID, "main"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemGroup.btth_heavenly_flames.main"))
                    .icon(() -> new ItemStack(ModItems.GOLD_EMPEROR_INCINERATING_FLAME))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.GREEN_LOTUS_CORE_FLAME);
                        out.accept(ModItems.FALLEN_HEART_FLAME);
                        out.accept(ModItems.SEA_HEART_FLAME);
                        out.accept(ModItems.BONE_CHILLING_FLAME);
                        out.accept(ModItems.NINE_DRAGON_LIGHTNING_FLAME);
                        out.accept(ModItems.THREE_THOUSAND_BURNING_FLAME);
                        out.accept(ModItems.GOLD_EMPEROR_INCINERATING_FLAME);
                        out.accept(ModItems.PURIFYING_DEMONIC_LOTUS_FLAME);
                        out.accept(ModItems.NIHILITY_DEVOURING_FLAME);
                        out.accept(ModItems.FLAME_REFINING_ALTAR);
                        out.accept(ModItems.HEAVENLY_FLAME_ESSENCE);
                        out.accept(ModItems.HEAVENLY_BACK_RING);
                        out.accept(ModItems.FLAME_HELMET);
                        out.accept(ModItems.FLAME_CHESTPLATE);
                        out.accept(ModItems.FLAME_LEGGINGS);
                        out.accept(ModItems.FLAME_BOOTS);
                        out.accept(ModItems.XIAO_CLAN_CREST);
                        out.accept(ModItems.JIA_NAN_ACADEMY_CREST);
                        out.accept(ModItems.YUN_LAN_SECT_CREST);
                        out.accept(ModItems.MITRE_CLAN_CREST);
                    })
                    .build()
    );

    public static void register() {}
}
