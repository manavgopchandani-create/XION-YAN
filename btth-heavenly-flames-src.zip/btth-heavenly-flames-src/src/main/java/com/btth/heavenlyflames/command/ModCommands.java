package com.btth.heavenlyflames.command;

import com.btth.heavenlyflames.component.PlayerFlameData;
import com.btth.heavenlyflames.util.CultivationRealms;
import com.btth.heavenlyflames.util.FlameDataHelper;
import com.btth.heavenlyflames.util.FlameMoves;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class ModCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> registerCommands(dispatcher));
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("btth")
                .then(Commands.literal("status").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    PlayerFlameData d = FlameDataHelper.get(p);
                    p.displayClientMessage(Component.literal("§6=== BTTH Status ==="), false);
                    p.displayClientMessage(Component.literal("§eRealm: §f" + CultivationRealms.getName(d.getCultivationRank()) + " (" + d.getCultivationRank() + ")"), false);
                    p.displayClientMessage(Component.literal("§eFlames: §f" + d.getFlameCount() + " §7| Power: §f" + d.getFlamePower()), false);
                    p.displayClientMessage(Component.literal("§eRing Style: §f#" + d.getRingStyle() + (d.isRingsVisible() ? " §a(visible)" : " §7(hidden)")), false);
                    p.displayClientMessage(Component.literal("§eSelected: §f" + d.getSelectedFlameId()), false);
                    return 1;
                }))
                .then(Commands.literal("rings")
                        .then(Commands.literal("toggle").executes(ctx -> {
                            FlameMoves.toggleRings(ctx.getSource().getPlayerOrException());
                            return 1;
                        }))
                        .then(Commands.literal("reroll").executes(ctx -> {
                            FlameMoves.rerollRings(ctx.getSource().getPlayerOrException());
                            return 1;
                        }))
                        .then(Commands.literal("set").then(Commands.argument("style", IntegerArgumentType.integer(1, 8))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    PlayerFlameData d = FlameDataHelper.get(p);
                                    d.setRingStyle(IntegerArgumentType.getInteger(ctx, "style"));
                                    d.setRingsVisible(true);
                                    FlameDataHelper.set(p, d);
                                    p.displayClientMessage(Component.literal("§dRing style set to #" + d.getRingStyle()), true);
                                    return 1;
                                }))))
                .then(Commands.literal("power").then(Commands.argument("amount", IntegerArgumentType.integer(0))
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            PlayerFlameData d = FlameDataHelper.get(p);
                            d.addFlamePower(IntegerArgumentType.getInteger(ctx, "amount"));
                            FlameDataHelper.set(p, d);
                            p.displayClientMessage(Component.literal("§aFlame power now " + d.getFlamePower()), true);
                            return 1;
                        })))
        );
    }
}
