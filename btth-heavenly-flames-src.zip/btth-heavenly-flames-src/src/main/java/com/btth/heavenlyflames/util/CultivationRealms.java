package com.btth.heavenlyflames.util;

public class CultivationRealms {
    public static final String[] NAMES = {
        "Dou Zhi Qi",      // 1
        "Dou Zhe",         // 2
        "Dou Shi",         // 3
        "Da Dou Shi",      // 4
        "Dou Ling",        // 5
        "Dou Wang",        // 6
        "Dou Huang",       // 7
        "Dou Zong",        // 8
        "Dou Zun",         // 9
        "Ban Sheng",       // 10
        "Dou Sheng",       // 11
        "Dou Di"           // 12
    };

    public static String getName(int rank) {
        int idx = Math.max(0, Math.min(rank - 1, NAMES.length - 1));
        return NAMES[idx];
    }
}
