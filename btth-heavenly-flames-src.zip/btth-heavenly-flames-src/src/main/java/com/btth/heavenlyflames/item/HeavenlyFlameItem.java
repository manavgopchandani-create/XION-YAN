package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.component.PlayerFlameData;
import com.btth.heavenlyflames.util.FlameDataHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class HeavenlyFlameItem extends Item {
    private final int rank;
    private final String flameId;
    private final String displayName;

    public HeavenlyFlameItem(Properties props, int rank, String flameId, String displayName) {
        super(props);
        this.rank = rank;
        this.flameId = flameId;
        this.displayName = displayName;
    }

    public int getRank() { return rank; }
    public String getFlameId() { return flameId; }
    public String getDisplayName() { return displayName; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }
        PlayerFlameData data = FlameDataHelper.get(player);
        if (data.hasFlame(flameId)) {
            // Refine / power up
            int powerGain = 10 + rank * 5;
            data.addFlamePower(powerGain);
            data.refineFlame(flameId, 1);
            FlameDataHelper.set(player, data);
            player.displayClientMessage(Component.literal("§6Refined " + displayName + " §7(+ " + powerGain + " flame power)"), true);
            player.displayClientMessage(Component.literal("§eRank: " + data.getCultivationRank() + " §7| Flames: " + data.getFlameCount() + " §7| Power: " + data.getFlamePower()), false);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        } else {
            // Absorb new flame
            data.addFlame(flameId, rank);
            data.addFlamePower(20 + rank * 10);
            // Randomize a back ring style when first absorbing
            if (data.getRingStyle() == 0) {
                data.setRingStyle(1 + level.random.nextInt(8)); // 1-8 styles
            }
            FlameDataHelper.set(player, data);
            player.displayClientMessage(Component.literal("§aAbsorbed §r" + displayName + "§a! Cultivation rises."), true);
            player.displayClientMessage(Component.literal("§eRank: " + data.getCultivationRank() + " §7| Flames: " + data.getFlameCount() + " §7| Power: " + data.getFlamePower()), false);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Rank: §e" + rank));
        tooltip.add(Component.literal("§8Right-click to absorb or refine"));
        tooltip.add(Component.literal("§8One of the legendary Heavenly Flames"));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
