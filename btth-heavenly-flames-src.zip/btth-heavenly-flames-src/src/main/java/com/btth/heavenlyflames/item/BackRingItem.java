package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.component.PlayerFlameData;
import com.btth.heavenlyflames.util.FlameDataHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class BackRingItem extends Item {
    public BackRingItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            PlayerFlameData data = FlameDataHelper.get(player);
            int newStyle = 1 + level.random.nextInt(8);
            data.setRingStyle(newStyle);
            data.setRingsVisible(true);
            FlameDataHelper.set(player, data);
            player.displayClientMessage(Component.literal("§dBack Ring style randomized → §f#" + newStyle), true);
        }
        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Right-click to randomize your cultivation back rings"));
        tooltip.add(Component.literal("§8Rings appear behind you based on rank & style"));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
