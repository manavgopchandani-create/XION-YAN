package com.btth.heavenlyflames.component;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PlayerFlameData {
    private final Set<String> flames = new HashSet<>();
    private final Map<String, Integer> refineLevels = new HashMap<>();
    private int flamePower = 0;
    private int cultivationRank = 1;
    private int selectedFlameIndex = 0;
    /** 0 = none, 1–8 = random visual style of the Dou Zun / Dou Sheng back rings */
    private int ringStyle = 0;
    private boolean ringsVisible = true;
    private int previousRank = 1;

    public boolean hasFlame(String id) { return flames.contains(id); }

    public void addFlame(String id, int rank) {
        flames.add(id);
        refineLevels.putIfAbsent(id, 1);
        recalculateRank();
    }

    public boolean refineFlame(String id, int amount) {
        if (!flames.contains(id)) return false;
        refineLevels.merge(id, amount, Integer::sum);
        recalculateRank();
        return true;
    }

    public int getFlameCount() { return flames.size(); }
    public int getFlamePower() { return flamePower; }

    public void addFlamePower(int amount) {
        flamePower += amount;
        recalculateRank();
    }

    public int getCultivationRank() { return cultivationRank; }
    public int getRingStyle() { return ringStyle; }
    public void setRingStyle(int style) { this.ringStyle = style; }
    public boolean isRingsVisible() { return ringsVisible; }
    public void setRingsVisible(boolean v) { ringsVisible = v; }
    public void toggleRings() { ringsVisible = !ringsVisible; }

    public int getSelectedFlameIndex() { return selectedFlameIndex; }

    public void cycleSelectedFlame() {
        if (flames.isEmpty()) return;
        selectedFlameIndex = (selectedFlameIndex + 1) % Math.max(1, flames.size());
    }

    public String getSelectedFlameId() {
        if (flames.isEmpty()) return null;
        int i = 0;
        for (String f : flames) {
            if (i == selectedFlameIndex % flames.size()) return f;
            i++;
        }
        return flames.iterator().next();
    }

    public Set<String> getFlames() { return flames; }
    public int getRefineLevel(String id) { return refineLevels.getOrDefault(id, 0); }

    /**
     * Rank formula tuned so Dou Zun (9) and Dou Sheng (11) are meaningful milestones.
     * Rank 9  = Dou Zun  → first back rings appear
     * Rank 11 = Dou Sheng → full multi-layer rings
     */
    private void recalculateRank() {
        previousRank = cultivationRank;
        int base = 1 + flames.size();
        int bonus = flamePower / 40;
        cultivationRank = Math.min(12, base + bonus);

        // On breakthrough into Dou Zun (9+) assign a random ring style if none yet
        if (cultivationRank >= 9 && ringStyle == 0) {
            ringStyle = 1 + (int) (Math.random() * 8);
            ringsVisible = true;
        }
        // Extra flair when crossing into Dou Sheng
        if (previousRank < 11 && cultivationRank >= 11 && ringStyle > 0) {
            // keep style, just ensure visible
            ringsVisible = true;
        }
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        ListTag list = new ListTag();
        for (String f : flames) list.add(StringTag.valueOf(f));
        tag.put("Flames", list);
        CompoundTag refines = new CompoundTag();
        for (Map.Entry<String, Integer> e : refineLevels.entrySet()) {
            refines.putInt(e.getKey(), e.getValue());
        }
        tag.put("Refines", refines);
        tag.putInt("FlamePower", flamePower);
        tag.putInt("CultivationRank", cultivationRank);
        tag.putInt("SelectedFlame", selectedFlameIndex);
        tag.putInt("RingStyle", ringStyle);
        tag.putBoolean("RingsVisible", ringsVisible);
        return tag;
    }

    public void load(CompoundTag tag) {
        flames.clear();
        refineLevels.clear();
        if (tag.contains("Flames", Tag.TAG_LIST)) {
            ListTag list = tag.getList("Flames", Tag.TAG_STRING);
            for (int i = 0; i < list.size(); i++) flames.add(list.getString(i));
        }
        if (tag.contains("Refines", Tag.TAG_COMPOUND)) {
            CompoundTag ref = tag.getCompound("Refines");
            for (String key : ref.getAllKeys()) refineLevels.put(key, ref.getInt(key));
        }
        flamePower = tag.getInt("FlamePower");
        cultivationRank = Math.max(1, tag.getInt("CultivationRank"));
        selectedFlameIndex = tag.getInt("SelectedFlame");
        ringStyle = tag.getInt("RingStyle");
        ringsVisible = !tag.contains("RingsVisible") || tag.getBoolean("RingsVisible");
        previousRank = cultivationRank;
    }
}
