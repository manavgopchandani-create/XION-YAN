package com.btth.heavenlyflames.network;

import com.btth.heavenlyflames.BtthHeavenlyFlames;
import com.btth.heavenlyflames.util.FlameMoves;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

public class ModPackets {
    public static final ResourceLocation MOVE_PACKET = new ResourceLocation(BtthHeavenlyFlames.MOD_ID, "move");

    // payload: one byte — 0 primary, 1 secondary, 2 special, 3 cycle, 4 toggle rings, 5 reroll rings

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(MOVE_PACKET, (server, player, handler, buf, responseSender) -> {
            byte action = buf.readByte();
            server.execute(() -> handle(player, action));
        });
    }

    private static void handle(ServerPlayer player, byte action) {
        switch (action) {
            case 0 -> FlameMoves.primaryMove(player);
            case 1 -> FlameMoves.secondaryMove(player);
            case 2 -> FlameMoves.specialMove(player);
            case 3 -> FlameMoves.cycleFlame(player);
            case 4 -> FlameMoves.toggleRings(player);
            case 5 -> FlameMoves.rerollRings(player);
            default -> {}
        }
    }
}
