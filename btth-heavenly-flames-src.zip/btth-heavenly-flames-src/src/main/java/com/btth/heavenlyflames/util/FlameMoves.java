package com.btth.heavenlyflames.util;

import com.btth.heavenlyflames.component.PlayerFlameData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class FlameMoves {

    public static void primaryMove(ServerPlayer player) {
        PlayerFlameData data = FlameDataHelper.get(player);
        if (data.getFlameCount() == 0) {
            player.displayClientMessage(Component.literal("§cYou have no Heavenly Flames!"), true);
            return;
        }
        String flame = data.getSelectedFlameId();
        int power = 4 + data.getFlamePower() / 20 + data.getCultivationRank();
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        Vec3 start = player.getEyePosition();

        for (int i = 1; i <= 12; i++) {
            Vec3 pos = start.add(look.scale(i * 0.9));
            level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 4, 0.15, 0.15, 0.15, 0.02);
            if (flame != null && flame.contains("bone")) {
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y, pos.z, 2, 0.1, 0.1, 0.1, 0.01);
            }
            if (flame != null && (flame.contains("nine") || flame.contains("dragon"))) {
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 3, 0.2, 0.2, 0.2, 0.05);
            }
            if (flame != null && flame.contains("nihility")) {
                level.sendParticles(ParticleTypes.SCULK_SOUL, pos.x, pos.y, pos.z, 2, 0.1, 0.1, 0.1, 0.01);
            }
        }
        level.playSound(null, player.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.9f, 0.8f + level.random.nextFloat() * 0.4f);

        AABB box = player.getBoundingBox().expandTowards(look.scale(10)).inflate(1.8);
        List<Entity> targets = level.getEntities(player, box, e -> e instanceof LivingEntity && e != player && e.isAlive());
        for (Entity e : targets) {
            Vec3 to = e.position().subtract(player.position()).normalize();
            if (to.dot(look) > 0.55) {
                e.hurt(player.damageSources().magic(), power);
                e.setSecondsOnFire(3 + data.getCultivationRank() / 2);
                e.setDeltaMovement(e.getDeltaMovement().add(look.scale(0.4)));
            }
        }
        player.displayClientMessage(Component.literal("§6【Primary】 " + (flame != null ? flame : "Flame") + " Burst!"), true);
    }

    public static void secondaryMove(ServerPlayer player) {
        PlayerFlameData data = FlameDataHelper.get(player);
        if (data.getFlameCount() == 0) {
            player.displayClientMessage(Component.literal("§cYou have no Heavenly Flames!"), true);
            return;
        }
        String flame = data.getSelectedFlameId();
        ServerLevel level = player.serverLevel();
        int power = 3 + data.getFlamePower() / 30;

        for (int i = 0; i < 40; i++) {
            double ang = (i / 40.0) * Math.PI * 2;
            double r = 2.5 + level.random.nextDouble();
            double x = player.getX() + Math.cos(ang) * r;
            double z = player.getZ() + Math.sin(ang) * r;
            double y = player.getY() + 0.3 + level.random.nextDouble() * 1.5;
            level.sendParticles(ParticleTypes.FLAME, x, y, z, 2, 0.05, 0.1, 0.05, 0.01);
            if (flame != null && flame.contains("lotus")) {
                level.sendParticles(ParticleTypes.CHERRY_LEAVES, x, y, z, 1, 0.1, 0.1, 0.1, 0);
            }
        }
        level.playSound(null, player.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.0f, 0.7f);

        AABB box = player.getBoundingBox().inflate(4.5);
        List<Entity> targets = level.getEntities(player, box, e -> e instanceof LivingEntity && e != player && e.isAlive());
        for (Entity e : targets) {
            e.hurt(player.damageSources().magic(), power);
            e.setSecondsOnFire(2);
            Vec3 dir = player.position().subtract(e.position()).normalize().scale(0.25);
            e.setDeltaMovement(e.getDeltaMovement().add(dir));
        }
        player.setHealth(Math.min(player.getMaxHealth(), player.getHealth() + 1.0f));
        player.displayClientMessage(Component.literal("§d【Secondary】 Flame Domain / Lotus Guard"), true);
    }

    public static void specialMove(ServerPlayer player) {
        PlayerFlameData data = FlameDataHelper.get(player);
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        player.setDeltaMovement(look.scale(1.6).add(0, 0.25, 0));
        player.hurtMarked = true;

        for (int i = 0; i < 20; i++) {
            Vec3 pos = player.position().add(look.scale(-i * 0.3)).add(0, 1, 0);
            level.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 2, 0.1, 0.1, 0.1, 0.02);
            level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 1, 0.05, 0.05, 0.05, 0.01);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 0.6f, 1.4f);
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, 40, 1, false, false, true));
        player.displayClientMessage(Component.literal("§b【Special】 Flame Step"), true);
    }

    public static void cycleFlame(ServerPlayer player) {
        PlayerFlameData data = FlameDataHelper.get(player);
        if (data.getFlameCount() == 0) {
            player.displayClientMessage(Component.literal("§cNo flames to cycle."), true);
            return;
        }
        data.cycleSelectedFlame();
        FlameDataHelper.set(player, data);
        player.displayClientMessage(Component.literal("§eSelected flame: §f" + data.getSelectedFlameId()), true);
    }

    public static void toggleRings(ServerPlayer player) {
        PlayerFlameData data = FlameDataHelper.get(player);
        if (data.getCultivationRank() < 9) {
            player.displayClientMessage(Component.literal("§cBack rings only appear at §6Dou Zun§c and above (rank 9+)."), true);
            return;
        }
        data.toggleRings();
        if (data.getRingStyle() == 0) {
            data.setRingStyle(1 + player.level().random.nextInt(8));
        }
        FlameDataHelper.set(player, data);
        String realm = CultivationRealms.getName(data.getCultivationRank());
        player.displayClientMessage(Component.literal(
                data.isRingsVisible()
                        ? "§aDou Zun/Sheng Back Rings: ON §7(style #" + data.getRingStyle() + ", " + realm + ")"
                        : "§7Back Rings: OFF"
        ), true);
    }

    public static void rerollRings(ServerPlayer player) {
        PlayerFlameData data = FlameDataHelper.get(player);
        if (data.getCultivationRank() < 9) {
            player.displayClientMessage(Component.literal("§cReach §6Dou Zun§c (rank 9) first to manifest back rings."), true);
            return;
        }
        int style = 1 + player.level().random.nextInt(8);
        data.setRingStyle(style);
        data.setRingsVisible(true);
        FlameDataHelper.set(player, data);
        player.displayClientMessage(Component.literal("§dRandomized cultivation back-ring style → §f#" + style + " §7(Dou Zun / Dou Sheng rings)"), true);
    }
}
