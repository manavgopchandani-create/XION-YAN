package com.btth.heavenlyflames.client;

import com.btth.heavenlyflames.BtthHeavenlyFlames;
import com.btth.heavenlyflames.client.keybind.ModKeybinds;
import com.btth.heavenlyflames.client.render.BackRingRenderer;
import com.btth.heavenlyflames.network.ModPackets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import io.netty.buffer.Unpooled;

public class BtthHeavenlyFlamesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModKeybinds.register();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (ModKeybinds.PRIMARY.consumeClick()) sendMove((byte) 0);
            while (ModKeybinds.SECONDARY.consumeClick()) sendMove((byte) 1);
            while (ModKeybinds.SPECIAL.consumeClick()) sendMove((byte) 2);
            while (ModKeybinds.CYCLE_FLAME.consumeClick()) sendMove((byte) 3);
            while (ModKeybinds.TOGGLE_RINGS.consumeClick()) sendMove((byte) 4);
            while (ModKeybinds.REROLL_RINGS.consumeClick()) sendMove((byte) 5);
        });

        // Render back rings for local + other players (simple local for now)
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.level != null) {
                BackRingRenderer.render(context, mc.player);
            }
        });

        BtthHeavenlyFlames.LOGGER.info("Client: Keybinds + Back Ring renderer ready");
    }

    private static void sendMove(byte action) {
        FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
        buf.writeByte(action);
        ClientPlayNetworking.send(ModPackets.MOVE_PACKET, buf);
    }
}
