package com.btth.heavenlyflames.client.keybind;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class ModKeybinds {
    public static KeyMapping PRIMARY;
    public static KeyMapping SECONDARY;
    public static KeyMapping SPECIAL;
    public static KeyMapping CYCLE_FLAME;
    public static KeyMapping TOGGLE_RINGS;
    public static KeyMapping REROLL_RINGS;

    public static void register() {
        PRIMARY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.btth_heavenly_flames.primary",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "key.category.btth_heavenly_flames"
        ));
        SECONDARY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.btth_heavenly_flames.secondary",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "key.category.btth_heavenly_flames"
        ));
        SPECIAL = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.btth_heavenly_flames.special",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "key.category.btth_heavenly_flames"
        ));
        CYCLE_FLAME = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.btth_heavenly_flames.cycle",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "key.category.btth_heavenly_flames"
        ));
        TOGGLE_RINGS = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.btth_heavenly_flames.toggle_rings",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "key.category.btth_heavenly_flames"
        ));
        REROLL_RINGS = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.btth_heavenly_flames.reroll_rings",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_Y,
                "key.category.btth_heavenly_flames"
        ));
    }
}
