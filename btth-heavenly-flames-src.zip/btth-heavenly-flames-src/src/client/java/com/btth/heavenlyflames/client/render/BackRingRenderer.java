package com.btth.heavenlyflames.client.render;

import com.btth.heavenlyflames.component.PlayerFlameData;
import com.btth.heavenlyflames.util.FlameDataHelper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/**
 * Renders the cultivation energy rings that appear behind high-rank cultivators
 * in Battle Through the Heavens — the signature rings Xiao Yan manifests
 * when he reaches Dou Zun and the even grander rings at Dou Sheng.
 *
 * Rank gates (matching the novel/donghua feel):
 *   Rank 9  Dou Zun   → first true back rings (1–2 layers)
 *   Rank 10 Ban Sheng → stronger, 2–3 layers
 *   Rank 11 Dou Sheng → full multi-ring display (3–4 layers)
 *   Rank 12 Dou Di    → peak, densest rings + core
 *
 * Style 1–8 is random (assigned on breakthrough / reroll) and only changes color & spin.
 */
public class BackRingRenderer {

    // Random style palettes (still random as requested)
    private static final float[][] STYLE_COLORS = {
            {1.00f, 0.82f, 0.25f},  // 1 pure gold (classic Xiao Yan / Emperor)
            {0.25f, 0.95f, 0.40f},  // 2 Green Lotus
            {0.95f, 0.25f, 0.65f},  // 3 Fallen Heart
            {0.25f, 0.55f, 1.00f},  // 4 Sea Heart
            {0.55f, 0.95f, 1.00f},  // 5 Bone Chilling
            {0.75f, 0.30f, 1.00f},  // 6 Nine Dragon Lightning
            {1.00f, 0.45f, 0.08f},  // 7 Three Thousand Burning
            {0.55f, 0.15f, 0.70f},  // 8 Nihility / Purifying Lotus
    };

    public static void render(WorldRenderContext ctx, LocalPlayer local) {
        PlayerFlameData data = FlameDataHelper.get(local);
        int rank = data.getCultivationRank();

        // True Dou Zun+ rings only (rank 9+)
        if (!data.isRingsVisible() || data.getRingStyle() <= 0 || rank < 9) {
            return;
        }

        int style = Mth.clamp(data.getRingStyle(), 1, 8);
        float[] col = STYLE_COLORS[style - 1];

        // How many rings based on realm (donghua-accurate progression)
        int ringCount;
        float baseRadius;
        float intensity;
        if (rank >= 12) {          // Dou Di
            ringCount = 4;
            baseRadius = 0.70f;
            intensity = 1.0f;
        } else if (rank >= 11) {   // Dou Sheng
            ringCount = 4;
            baseRadius = 0.65f;
            intensity = 0.95f;
        } else if (rank >= 10) {   // Ban Sheng
            ringCount = 3;
            baseRadius = 0.60f;
            intensity = 0.85f;
        } else {                   // Dou Zun (9)
            ringCount = 2;
            baseRadius = 0.55f;
            intensity = 0.75f;
        }

        float time = (local.tickCount + ctx.tickDelta()) * 0.04f;
        var matrices = ctx.matrixStack();
        matrices.pushPose();

        double x = local.xOld + (local.getX() - local.xOld) * ctx.tickDelta();
        double y = local.yOld + (local.getY() - local.yOld) * ctx.tickDelta() + local.getBbHeight() * 0.55;
        double z = local.zOld + (local.getZ() - local.zOld) * ctx.tickDelta();

        // Place rings behind the body (facing-aligned), like the donghua
        float yaw = local.yBodyRot;
        double backX = -Mth.sin(yaw * Mth.DEG_TO_RAD) * 0.65;
        double backZ =  Mth.cos(yaw * Mth.DEG_TO_RAD) * 0.65;

        var cam = ctx.camera().getPosition();
        matrices.translate(x - cam.x + backX, y - cam.y, z - cam.z + backZ);

        // Slight face-camera tilt so rings read as vertical disks behind the character
        matrices.mulPose(com.mojang.math.Axis.YP.rotationDegrees(-yaw));

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.depthMask(false);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        Matrix4f mat = matrices.last().pose();

        for (int r = 0; r < ringCount; r++) {
            float radius = baseRadius + r * 0.32f;
            float spin = time * (0.9f + r * 0.35f) * ((style + r) % 2 == 0 ? 1f : -1f);
            float alpha = (0.70f - r * 0.12f) * intensity;
            int segments = 64;

            // Main energy ring (DEBUG_LINE_STRIP = clean glowing circle)
            buf.begin(VertexFormat.Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
            for (int i = 0; i <= segments; i++) {
                float ang = (i / (float) segments) * Mth.TWO_PI + spin;
                float px = Mth.cos(ang) * radius;
                float py = Mth.sin(ang) * radius;
                // Slight depth wave so it feels alive
                float pz = Mth.sin(ang * 2f + time * 1.5f) * 0.04f;
                buf.vertex(mat, px, py, pz)
                        .color(col[0], col[1], col[2], alpha)
                        .endVertex();
            }
            tess.end();

            // Inner bright core line (thinner, brighter)
            float innerR = radius * 0.92f;
            buf.begin(VertexFormat.Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
            for (int i = 0; i <= segments; i++) {
                float ang = (i / (float) segments) * Mth.TWO_PI + spin * 1.1f;
                float px = Mth.cos(ang) * innerR;
                float py = Mth.sin(ang) * innerR;
                buf.vertex(mat, px, py, 0)
                        .color(1f, 0.95f, 0.75f, alpha * 0.85f)
                        .endVertex();
            }
            tess.end();

            // Radial energy spokes (dou sheng / di only)
            if (rank >= 11 && r < 2) {
                buf.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
                int spokes = 8 + r * 4;
                for (int i = 0; i < spokes; i++) {
                    float ang = (i / (float) spokes) * Mth.TWO_PI + spin * 0.5f;
                    float px = Mth.cos(ang) * radius;
                    float py = Mth.sin(ang) * radius;
                    buf.vertex(mat, px * 0.35f, py * 0.35f, 0)
                            .color(col[0], col[1], col[2], 0f).endVertex();
                    buf.vertex(mat, px, py, 0)
                            .color(1f, 1f, 0.9f, alpha * 0.5f).endVertex();
                }
                tess.end();
            }
        }

        // Central core (Dou Sheng+)
        if (rank >= 10) {
            float pulse = 0.12f + 0.06f * Mth.sin(time * 4f);
            buf.begin(VertexFormat.Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
            for (int i = 0; i <= 32; i++) {
                float ang = (i / 32f) * Mth.TWO_PI - time * 2.5f;
                buf.vertex(mat, Mth.cos(ang) * pulse, Mth.sin(ang) * pulse, 0)
                        .color(1f, 0.98f, 0.8f, 0.9f * intensity).endVertex();
            }
            tess.end();
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        matrices.popPose();
    }
}
