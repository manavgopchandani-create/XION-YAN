# BTTH Heavenly Flames — Cultivation Expansion (Fabric 1.20.1)

A fan-made Minecraft Java mod inspired by the *Battle Through the Heavens* donghua. This edition expands the existing Heavenly Flame collection with a named cultivation ladder and simple progression testing commands.

## Included in this source update

- Named cultivation progression: Dou Zhi Qi → Dou Zhe → Dou Shi → Da Dou Shi → Dou Ling → Dou Wang → Dou Huang → Dou Zong → Dou Zun → Ban Sheng → Dou Sheng → Dou Di.
- Star levels for most realms, displayed by `/btth status` and `/btth realm`.
- `/btth breakthrough` adds one progression rank and plays a vanilla beacon sound; it announces when the displayed realm changes.
- Existing Heavenly Flame items, refining, saved player progression, creative tab, and administrative test commands remain in place.
- Built for Minecraft Java 1.20.1, Fabric, Java 17, and Fabric API.

## Commands (requires permission level 2 / cheats)

- `/btth status` — realm, progression rank, refined flames, and flame power
- `/btth realm` — show current named realm
- `/btth breakthrough` — add one progression rank for testing
- `/btth give <flame>` — give a registered flame item
- `/btth setrank <0-100>` — set progression rank directly
- `/btth clearflames` — clear refined flame ownership

Flame keys: `green_lotus`, `fallen_heart`, `sea_heart`, `bone_chilling`, `nine_dragon`, `three_thousand`, `gold_emperor`, `purifying_lotus`, `nihility`.

## Build

Use JDK 17 and run `gradle build` (or `./gradlew build` if a Gradle wrapper is available). The output JAR is normally under `build/libs/`.

## Animation and compatibility notes

This update uses a vanilla sound cue for breakthroughs. It does **not** yet include custom animated player models, aura rendering, skill animations, new dimensions, or compatibility patches for other mods. Those require additional client rendering code/assets and need testing against the exact mods and versions installed. Don't install random mods as dependencies; use versions explicitly compatible with Minecraft 1.20.1 and Fabric.

This is a fan project and is not affiliated with the creators or rights holders of *Battle Through the Heavens*.


## Cultivator aura VFX (client-side)

When a player holds a registered Heavenly Flame in either hand, the client now renders a light rotating ember ring, rising sparks, enchantment shimmer, and a small sprint trail. It uses Minecraft 1.20.1 vanilla particles and Fabric API client tick events, avoiding mandatory animation-library dependencies and keeping particle counts modest for mobile devices.

This is a first VFX pass, not a complete recreation of the donghua. Unique flame colors, model animations, skill cinematics, bosses, sects, alchemy, and deeper story progression remain future features.


## Flame armor and clan insignias (new source expansion)

- Added a mod icon (`assets/btth_heavenly_flames/icon.png`) and custom item icons.
- Added a four-piece Heavenly Flame armor set (helmet, chestplate, leggings, boots).
- Added collectible clan/sect insignias for the Xiao Clan, Jia Nan Academy, Yun Lan Sect, and Mite'er Clan.
- Clan crests are currently identity/collectible items; they do not yet provide full faction membership, reputation, or quest logic.
- Armor textures are initial fan-made placeholders and should be visually polished after an in-game build test.

Build for Minecraft 1.20.1 / Fabric / Java 17 using the repository's GitHub Actions workflow or Gradle environment.


## New cultivation expansion (experimental)

- `/btth clan` — show your current clan or sect.
- `/btth clan join xiao` — join Xiao Clan.
- `/btth clan join yun_lan` — join Yun Lan Sect.
- `/btth clan join mitre` — join Mite'er Clan.
- `/btth clan join jia_nan` — join Jia Nan Academy.

Clan membership is saved with the player's BTTH data. These are starter gameplay systems: clan-specific quests, passive bonuses, faction reputation, animated armor models, and cinematic attacks remain planned work. Use operator permissions (level 2) for `/btth` commands.


## Experimental combat skills

The operator command `/btth skill <name>` now has four server-side area abilities:

- `inferno` — flame burst and burning damage
- `lotus` — wider, heavier flame burst
- `lightning` — electric sparks, damage, and a small launch effect
- `devour` — void-like portal burst

Skills have per-player cooldowns saved with cultivation data. To avoid accidental PvP griefing, player targets are excluded. These commands currently inherit the `/btth` operator permission requirement.
