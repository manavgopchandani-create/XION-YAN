package com.btth.heavenlyflames.client;

import com.btth.heavenlyflames.item.HeavenlyFlameItem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Lightweight client-side aura VFX. Uses vanilla particles, so no extra assets/dependencies are needed. */
public class BtthHeavenlyFlamesClient implements ClientModInitializer {
    private static long ticks;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null || client.player == null || client.isPaused()) return;
            ticks++;
            PlayerEntity player = client.player;
            ItemStack held = player.getStackInHand(Hand.MAIN_HAND);
            if (!(held.getItem() instanceof HeavenlyFlameItem)) {
                held = player.getStackInHand(Hand.OFF_HAND);
            }
            if (held.getItem() instanceof HeavenlyFlameItem) renderFlameAura(client, player, held);
        });
    }

    private static void renderFlameAura(MinecraftClient client, PlayerEntity player, ItemStack stack) {
        // Keep particle count deliberately modest for Android / lower-end devices.
        double phase = ticks * 0.16D;
        double radius = 0.62D;
        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();
        var world = client.world;

        // Rotating ember ring around the cultivator.
        for (int i = 0; i < 2; i++) {
            double angle = phase + i * Math.PI;
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            world.addParticle(ParticleTypes.FLAME, px, y + 0.25D + (Math.sin(phase * 1.4D) + 1D) * 0.28D,
                    pz, 0.0D, 0.025D, 0.0D);
        }

        // Sparse rising sparks and a faint mystical shimmer.
        if (ticks % 3 == 0) {
            double angle = phase * 1.7D;
            world.addParticle(ParticleTypes.SMALL_FLAME,
                    x + Math.cos(angle) * 0.38D, y + 0.15D + Math.random() * 1.4D,
                    z + Math.sin(angle) * 0.38D, 0.0D, 0.035D, 0.0D);
        }
        if (ticks % 6 == 0) {
            double angle = phase * 0.7D + Math.PI;
            world.addParticle(ParticleTypes.ENCHANT,
                    x + Math.cos(angle) * 0.48D, y + 0.45D + Math.random() * 1.0D,
                    z + Math.sin(angle) * 0.48D, 0.0D, 0.04D, 0.0D);
        }

        // A stronger burst while sprinting gives the aura a movement trail.
        if (player.isSprinting() && ticks % 2 == 0) {
            Vec3d look = player.getRotationVec(1.0F);
            world.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                    x - look.x * 0.45D, y + 0.25D, z - look.z * 0.45D,
                    -look.x * 0.04D, 0.02D, -look.z * 0.04D);
        }
    }
}
