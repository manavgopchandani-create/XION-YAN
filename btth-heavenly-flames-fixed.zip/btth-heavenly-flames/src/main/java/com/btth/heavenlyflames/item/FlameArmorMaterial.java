package com.btth.heavenlyflames.item;

import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/** Durable fan-made flame armor material for Minecraft 1.20.1. */
public enum FlameArmorMaterial implements ArmorMaterial {
    HEAVENLY_FLAME("heavenly_flame", 33, new int[]{3, 6, 8, 3}, 18, SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE, 2.5F, 0.1F),
    LOTUS_FLAME("lotus_flame", 25, new int[]{2, 5, 6, 2}, 14, SoundEvents.ITEM_ARMOR_EQUIP_GOLD, 1.5F, 0.0F);

    private final String name;
    private final int durabilityMultiplier;
    private final int[] protection;
    private final int enchantability;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;

    FlameArmorMaterial(String name, int durabilityMultiplier, int[] protection, int enchantability,
                       SoundEvent equipSound, float toughness, float knockbackResistance) {
        this.name = name; this.durabilityMultiplier = durabilityMultiplier; this.protection = protection;
        this.enchantability = enchantability; this.equipSound = equipSound; this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
    }
    @Override public int getDurability(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 11 * durabilityMultiplier;
            case CHESTPLATE -> 16 * durabilityMultiplier;
            case LEGGINGS -> 15 * durabilityMultiplier;
            case BOOTS -> 13 * durabilityMultiplier;
        };
    }
    @Override public int getProtection(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> protection[3];
            case CHESTPLATE -> protection[2];
            case LEGGINGS -> protection[1];
            case BOOTS -> protection[0];
        };
    }
    @Override public int getEnchantability() { return enchantability; }
    @Override public SoundEvent getEquipSound() { return equipSound; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.BLAZE_POWDER); }
    @Override public String getName() { return new Identifier("btth_heavenly_flames", name).toString(); }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockbackResistance; }
}
