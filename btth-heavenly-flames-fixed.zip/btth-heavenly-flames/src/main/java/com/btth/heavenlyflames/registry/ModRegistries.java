package com.btth.heavenlyflames.registry;

import com.btth.heavenlyflames.BtthHeavenlyFlames;

public class ModRegistries {
    public static void registerModStuff() {
        // Future: Register blocks, entities, status effects, custom attributes,
        // worldgen features for flame veins, structures, etc.
        BtthHeavenlyFlames.LOGGER.info("Registering additional systems for Heavenly Flames");
    }
}
