package com.btth.heavenlyflames.component;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * World-level saved data holding every player's refined flames and cultivation rank,
 * keyed by player UUID. Minecraft stores it in the world's data folder
 * (data/btth_heavenly_flames.dat), so it survives relogs and server restarts.
 * Call markDirty() after changing anything, or the change will not be written to disk.
 */
public class FlameSavedData extends PersistentState {
    private static final String SAVE_ID = "btth_heavenly_flames";
    private static final String PLAYERS_KEY = "Players";

    private final Map<UUID, PlayerFlameData> players = new HashMap<>();

    public PlayerFlameData getOrCreate(UUID playerId) {
        return players.computeIfAbsent(playerId, id -> new PlayerFlameData());
    }

    public void put(UUID playerId, PlayerFlameData data) {
        players.put(playerId, data);
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound playersNbt = new NbtCompound();
        for (Map.Entry<UUID, PlayerFlameData> entry : players.entrySet()) {
            playersNbt.put(entry.getKey().toString(), entry.getValue().writeNbt());
        }
        nbt.put(PLAYERS_KEY, playersNbt);
        return nbt;
    }

    public static FlameSavedData fromNbt(NbtCompound nbt) {
        FlameSavedData state = new FlameSavedData();
        NbtCompound playersNbt = nbt.getCompound(PLAYERS_KEY);
        for (String key : playersNbt.getKeys()) {
            UUID playerId;
            try {
                playerId = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                continue; // skip any entry whose key is not a valid UUID
            }
            PlayerFlameData data = new PlayerFlameData();
            data.readNbt(playersNbt.getCompound(key));
            state.players.put(playerId, data);
        }
        return state;
    }

    public static FlameSavedData get(MinecraftServer server) {
        ServerWorld overworld = server.getWorld(World.OVERWORLD);
        if (overworld == null) {
            throw new IllegalStateException("The overworld is not loaded yet");
        }
        PersistentStateManager manager = overworld.getPersistentStateManager();
        return manager.getOrCreate(FlameSavedData::fromNbt, FlameSavedData::new, SAVE_ID);
    }
}
