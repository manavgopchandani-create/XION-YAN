package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.BtthHeavenlyFlames;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemGroups {
    public static final ItemGroup BTTH_FLAMES_GROUP = Registry.register(Registries.ITEM_GROUP,
            new Identifier(BtthHeavenlyFlames.MOD_ID, "btth_flames"),
            FabricItemGroup.builder()
                    .displayName(Text.translatable("itemGroup.btth_heavenly_flames.main"))
                    .icon(() -> new ItemStack(ModItems.GREEN_LOTUS_CORE_FLAME))
                    .entries((displayContext, entries) -> {
                        // All Heavenly Flames
                        entries.add(ModItems.GREEN_LOTUS_CORE_FLAME);
                        entries.add(ModItems.FALLEN_HEART_FLAME);
                        entries.add(ModItems.SEA_HEART_FLAME);
                        entries.add(ModItems.BONE_CHILLING_FLAME);
                        entries.add(ModItems.NINE_DRAGON_LIGHTNING_FLAME);
                        entries.add(ModItems.THREE_THOUSAND_BURNING_FLAME);
                        entries.add(ModItems.GOLD_EMPEROR_INCINERATING_FLAME);
                        entries.add(ModItems.PURIFYING_DEMONIC_LOTUS_FLAME);
                        entries.add(ModItems.NIHILITY_DEVOURING_FLAME);

                        // Flame armor
                        entries.add(ModItems.FLAME_HELMET);
                        entries.add(ModItems.FLAME_CHESTPLATE);
                        entries.add(ModItems.FLAME_LEGGINGS);
                        entries.add(ModItems.FLAME_BOOTS);

                        // Clan insignias
                        entries.add(ModItems.XIAO_CLAN_CREST);
                        entries.add(ModItems.JIA_NAN_ACADEMY_CREST);
                        entries.add(ModItems.YUN_LAN_SECT_CREST);
                        entries.add(ModItems.MITRE_CLAN_CREST);

                        // Utility
                        entries.add(ModItems.HEAVENLY_FLAME_ESSENCE);
                        entries.add(ModItems.FLAME_REFINING_ALTAR);
                    })
                    .build());

    public static void registerItemGroups() {
        BtthHeavenlyFlames.LOGGER.info("Registering Item Groups for " + BtthHeavenlyFlames.MOD_ID);
    }
}
