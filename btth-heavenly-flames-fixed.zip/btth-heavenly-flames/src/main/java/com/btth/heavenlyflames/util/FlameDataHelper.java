package com.btth.heavenlyflames.util;

import com.btth.heavenlyflames.component.FlameSavedData;
import com.btth.heavenlyflames.component.PlayerFlameData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;

import java.util.function.Consumer;

/**
 * Access to a player's flame data. The data lives in world-level saved data
 * (see FlameSavedData), so it persists across relogs and restarts.
 * Server-side only: call these after checking world.isClient.
 */
public class FlameDataHelper {

    public static PlayerFlameData get(PlayerEntity player) {
        return savedData(player).getOrCreate(player.getUuid());
    }

    public static void set(PlayerEntity player, PlayerFlameData data) {
        FlameSavedData saved = savedData(player);
        saved.put(player.getUuid(), data);
        saved.markDirty();
    }

    public static void modify(PlayerEntity player, Consumer<PlayerFlameData> action) {
        FlameSavedData saved = savedData(player);
        action.accept(saved.getOrCreate(player.getUuid()));
        saved.markDirty();
    }

    private static FlameSavedData savedData(PlayerEntity player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            throw new IllegalStateException("Flame data is only available on the server");
        }
        return FlameSavedData.get(server);
    }
}
