package com.btth.heavenlyflames;

import com.btth.heavenlyflames.command.ModCommands;
import com.btth.heavenlyflames.item.ModItemGroups;
import com.btth.heavenlyflames.item.ModItems;
import com.btth.heavenlyflames.registry.ModRegistries;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BtthHeavenlyFlames implements ModInitializer {
    public static final String MOD_ID = "btth_heavenly_flames";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing BTTH Heavenly Flames - Deep Cultivation Edition");

        ModItems.registerModItems();
        ModItemGroups.registerItemGroups();
        ModRegistries.registerModStuff();
        ModCommands.registerCommands();

        LOGGER.info("Heavenly Flames system loaded. The path to the Emperor Flame begins...");
    }
}
