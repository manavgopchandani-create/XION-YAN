package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.component.PlayerFlameData;
import com.btth.heavenlyflames.util.FlameDataHelper;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class HeavenlyFlameItem extends Item {
    private final int rank;          // Lower number = stronger (BTTH ranking 1-23)
    private final String flameId;    // Internal id used for data storage
    private final String displayName;

    public HeavenlyFlameItem(Settings settings, int rank, String flameId, String displayName) {
        super(settings);
        this.rank = rank;
        this.flameId = flameId;
        this.displayName = displayName;
    }

    public int getRank() {
        return rank;
    }

    public String getFlameId() {
        return flameId;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (world.isClient) {
            return TypedActionResult.success(stack);
        }

        PlayerFlameData data = FlameDataHelper.get(user);

        if (data.hasFlame(flameId)) {
            user.sendMessage(Text.literal("You have already refined the " + displayName + "!")
                    .formatted(Formatting.RED), true);
            return TypedActionResult.fail(stack);
        }

        // Success chance based on rank: weaker flames (higher rank number) are easier.
        // Rank 19 (Green Lotus) = 82.5%, Rank 2 (Nihility Devouring) = 40%
        float successChance = 0.95f - ((24 - rank) * 0.025f);
        successChance = Math.max(0.35f, Math.min(0.95f, successChance));

        // Creative mode always succeeds
        boolean isCreative = user.getAbilities().creativeMode;
        boolean success = isCreative || world.random.nextFloat() < successChance;

        if (success) {
            // Power contribution: lower rank number = more power
            int powerGain = Math.max(5, 30 - rank);

            data.refineFlame(flameId, powerGain);
            FlameDataHelper.set(user, data);

            if (!isCreative) {
                stack.decrement(1);
            }

            user.sendMessage(Text.literal("§6✦ You successfully refined the " + displayName + "!")
                    .formatted(Formatting.GOLD), true);
            user.sendMessage(Text.literal("Cultivation Rank: " + data.getCultivationRank() +
                    " | Flames: " + data.getFlameCount() + " | Flame Power: " + data.getFlamePower())
                    .formatted(Formatting.AQUA), false);

            world.playSound(null, user.getX(), user.getY(), user.getZ(),
                    SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, SoundCategory.PLAYERS, 1.0f, 1.2f);
        } else {
            // Failure: small damage + message
            user.damage(user.getDamageSources().magic(), 4.0f);
            user.sendMessage(Text.literal("§cThe " + displayName + " rejected you! Refining failed.")
                    .formatted(Formatting.RED), true);
            user.sendMessage(Text.literal("Try again when your cultivation is higher...")
                    .formatted(Formatting.GRAY), false);

            world.playSound(null, user.getX(), user.getY(), user.getZ(),
                    SoundEvents.ENTITY_GENERIC_BURN, SoundCategory.PLAYERS, 0.8f, 0.7f);
        }

        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.literal("Heavenly Flame Rank: #" + rank).formatted(Formatting.AQUA));
        tooltip.add(Text.literal(displayName).formatted(Formatting.GOLD));
        tooltip.add(Text.literal("Right-click to refine into your body").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("Creative Mode: Always succeeds").formatted(Formatting.GREEN));
        super.appendTooltip(stack, world, tooltip, context);
    }
}
