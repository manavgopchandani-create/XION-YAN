package com.btth.heavenlyflames.util;

/** Approximate BTTH cultivation ladder. Rank is a gameplay progression value, not canon power scaling. */
public final class CultivationRealms {
    private CultivationRealms() {}

    private static final String[] REALMS = {
        "Dou Zhi Qi", "Dou Zhe", "Dou Shi", "Da Dou Shi", "Dou Ling",
        "Dou Wang", "Dou Huang", "Dou Zong", "Dou Zun", "Ban Sheng", "Dou Sheng",
        "Dou Di"
    };

    public static String name(int rank) {
        int r = Math.max(0, Math.min(rank, 100));
        if (r <= 8) return REALMS[0] + " " + (r + 1) + " Star";
        if (r <= 16) return REALMS[1] + " " + (r - 8) + " Star";
        if (r <= 24) return REALMS[2] + " " + (r - 16) + " Star";
        if (r <= 32) return REALMS[3] + " " + (r - 24) + " Star";
        if (r <= 40) return REALMS[4] + " " + (r - 32) + " Star";
        if (r <= 48) return REALMS[5] + " " + (r - 40) + " Star";
        if (r <= 56) return REALMS[6] + " " + (r - 48) + " Star";
        if (r <= 64) return REALMS[7] + " " + (r - 56) + " Star";
        if (r <= 72) return REALMS[8] + " " + (r - 64) + " Star";
        if (r <= 80) return REALMS[9];
        if (r <= 98) return REALMS[10] + " " + (((r - 80 - 1) / 2) + 1) + " Star";
        return REALMS[11];
    }

    public static int nextThreshold(int rank) {
        if (rank < 8) return 9;
        if (rank < 16) return 17;
        if (rank < 24) return 25;
        if (rank < 32) return 33;
        if (rank < 40) return 41;
        if (rank < 48) return 49;
        if (rank < 56) return 57;
        if (rank < 64) return 65;
        if (rank < 72) return 73;
        if (rank < 80) return 81;
        if (rank < 98) return rank + 2;
        return 100;
    }
}
