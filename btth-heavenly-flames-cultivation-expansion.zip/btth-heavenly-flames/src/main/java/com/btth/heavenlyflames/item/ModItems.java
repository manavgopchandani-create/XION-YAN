package com.btth.heavenlyflames.item;

import com.btth.heavenlyflames.BtthHeavenlyFlames;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.item.ArmorItem;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {

    // === Heavenly Flame Seeds / Origin Flames ===
    // Ranked by BTTH ranking (lower number = stronger)

    public static final Item GREEN_LOTUS_CORE_FLAME = registerItem("green_lotus_core_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 19, "green_lotus_core_flame", "Green Lotus Core Flame"));

    public static final Item FALLEN_HEART_FLAME = registerItem("fallen_heart_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 14, "fallen_heart_flame", "Fallen Heart Flame"));

    public static final Item SEA_HEART_FLAME = registerItem("sea_heart_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 15, "sea_heart_flame", "Sea Heart Flame"));

    public static final Item BONE_CHILLING_FLAME = registerItem("bone_chilling_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 11, "bone_chilling_flame", "Bone Chilling Flame"));

    public static final Item NINE_DRAGON_LIGHTNING_FLAME = registerItem("nine_dragon_lightning_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 12, "nine_dragon_lightning_flame", "Nine Dragon Lightning Flame"));

    public static final Item THREE_THOUSAND_BURNING_FLAME = registerItem("three_thousand_burning_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 9, "three_thousand_burning_flame", "Three Thousand Burning Flame"));

    public static final Item GOLD_EMPEROR_INCINERATING_FLAME = registerItem("gold_emperor_incinerating_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 4, "gold_emperor_incinerating_flame", "Gold Emperor Incinerating Heavenly Flame"));

    public static final Item PURIFYING_DEMONIC_LOTUS_FLAME = registerItem("purifying_demonic_lotus_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 3, "purifying_demonic_lotus_flame", "Purifying Demonic Lotus Flame"));

    public static final Item NIHILITY_DEVOURING_FLAME = registerItem("nihility_devouring_flame",
            new HeavenlyFlameItem(new FabricItemSettings().maxCount(1), 2, "nihility_devouring_flame", "Nihility Devouring Flame"));


    // Flame armor set
    public static final Item FLAME_HELMET = registerItem("flame_helmet",
            new ArmorItem(FlameArmorMaterial.HEAVENLY_FLAME, EquipmentSlot.HEAD, new FabricItemSettings()));
    public static final Item FLAME_CHESTPLATE = registerItem("flame_chestplate",
            new ArmorItem(FlameArmorMaterial.HEAVENLY_FLAME, EquipmentSlot.CHEST, new FabricItemSettings()));
    public static final Item FLAME_LEGGINGS = registerItem("flame_leggings",
            new ArmorItem(FlameArmorMaterial.HEAVENLY_FLAME, EquipmentSlot.LEGS, new FabricItemSettings()));
    public static final Item FLAME_BOOTS = registerItem("flame_boots",
            new ArmorItem(FlameArmorMaterial.HEAVENLY_FLAME, EquipmentSlot.FEET, new FabricItemSettings()));

    // Clan insignias: collectible identity items; clan membership progression can build on these.
    public static final Item JIA_NAN_ACADEMY_CREST = registerItem("jia_nan_academy_crest", new Item(new FabricItemSettings().maxCount(1)));
    public static final Item YUN LAN_SECT_CREST = registerItem("yun_lan_sect_crest", new Item(new FabricItemSettings().maxCount(1)));
    public static final Item MITRE_CLAN_CREST = registerItem("mitre_clan_crest", new Item(new FabricItemSettings().maxCount(1)));
    public static final Item XIAO_CLAN_CREST = registerItem("xiao_clan_crest", new Item(new FabricItemSettings().maxCount(1)));

    // Utility items
    public static final Item FLAME_REFINING_ALTAR = registerItem("flame_refining_altar",
            new Item(new FabricItemSettings().maxCount(16)));

    public static final Item HEAVENLY_FLAME_ESSENCE = registerItem("heavenly_flame_essence",
            new Item(new FabricItemSettings()));

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(BtthHeavenlyFlames.MOD_ID, name), item);
    }

    public static void registerModItems() {
        BtthHeavenlyFlames.LOGGER.info("Registering Mod Items for " + BtthHeavenlyFlames.MOD_ID);
        // Items are registered statically above
    }
}
