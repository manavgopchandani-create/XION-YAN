package com.btth.heavenlyflames.command;

import com.btth.heavenlyflames.component.PlayerFlameData;
import com.btth.heavenlyflames.item.ModItems;
import com.btth.heavenlyflames.util.FlameDataHelper;
import com.btth.heavenlyflames.util.CultivationRealms;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Map;

public class ModCommands {

    private static final Map<String, Item> FLAME_MAP = Map.ofEntries(
            Map.entry("green_lotus", ModItems.GREEN_LOTUS_CORE_FLAME),
            Map.entry("fallen_heart", ModItems.FALLEN_HEART_FLAME),
            Map.entry("sea_heart", ModItems.SEA_HEART_FLAME),
            Map.entry("bone_chilling", ModItems.BONE_CHILLING_FLAME),
            Map.entry("nine_dragon", ModItems.NINE_DRAGON_LIGHTNING_FLAME),
            Map.entry("three_thousand", ModItems.THREE_THOUSAND_BURNING_FLAME),
            Map.entry("gold_emperor", ModItems.GOLD_EMPEROR_INCINERATING_FLAME),
            Map.entry("purifying_lotus", ModItems.PURIFYING_DEMONIC_LOTUS_FLAME),
            Map.entry("nihility", ModItems.NIHILITY_DEVOURING_FLAME)
    );

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("btth")
                    .requires(source -> source.hasPermissionLevel(2)) // OP level 2

                    // /btth status
                    .then(CommandManager.literal("status")
                            .executes(context -> {
                                ServerPlayerEntity player = context.getSource().getPlayer();
                                if (player == null) return 0;
                                PlayerFlameData data = FlameDataHelper.get(player);
                                context.getSource().sendFeedback(() -> Text.literal("§6=== Heavenly Flame Status ===")
                                        .formatted(Formatting.GOLD), false);
                                context.getSource().sendFeedback(() -> Text.literal("Cultivation: " + CultivationRealms.name(data.getCultivationRank()) + " (Rank " + data.getCultivationRank() + ")").formatted(Formatting.LIGHT_PURPLE), false);
                                context.getSource().sendFeedback(() -> Text.literal("Flames Refined: " + data.getFlameCount()), false);
                                context.getSource().sendFeedback(() -> Text.literal("Flame Power: " + data.getFlamePower()), false);
                                if (!data.getRefinedFlames().isEmpty()) {
                                    context.getSource().sendFeedback(() -> Text.literal("Owned: " + String.join(", ", data.getRefinedFlames())), false);
                                }
                                return 1;
                            }))

                    // /btth give <flame>
                    .then(CommandManager.literal("give")
                            .then(CommandManager.argument("flame", StringArgumentType.word())
                                    .suggests((context, builder) -> {
                                        FLAME_MAP.keySet().forEach(builder::suggest);
                                        return builder.buildFuture();
                                    })
                                    .executes(context -> {
                                        ServerPlayerEntity player = context.getSource().getPlayer();
                                        if (player == null) return 0;
                                        String key = StringArgumentType.getString(context, "flame").toLowerCase();
                                        Item flame = FLAME_MAP.get(key);
                                        if (flame == null) {
                                            context.getSource().sendError(Text.literal("Unknown flame. Available: " + String.join(", ", FLAME_MAP.keySet())));
                                            return 0;
                                        }
                                        player.giveItemStack(new ItemStack(flame));
                                        context.getSource().sendFeedback(() -> Text.literal("Gave " + key + " Heavenly Flame"), false);
                                        return 1;
                                    })))

                    // /btth setrank <number>
                    .then(CommandManager.literal("setrank")
                            .then(CommandManager.argument("rank", IntegerArgumentType.integer(0, 100))
                                    .executes(context -> {
                                        ServerPlayerEntity player = context.getSource().getPlayer();
                                        if (player == null) return 0;
                                        int rank = IntegerArgumentType.getInteger(context, "rank");
                                        FlameDataHelper.modify(player, data -> data.setCultivationRank(rank));
                                        context.getSource().sendFeedback(() -> Text.literal("Set cultivation rank to " + rank), false);
                                        return 1;
                                    })))

                    // /btth realm
                    .then(CommandManager.literal("realm")
                            .executes(context -> {
                                ServerPlayerEntity player = context.getSource().getPlayer();
                                if (player == null) return 0;
                                PlayerFlameData data = FlameDataHelper.get(player);
                                int rank = data.getCultivationRank();
                                context.getSource().sendFeedback(() -> Text.literal("✦ Cultivation Realm: " +
                                        CultivationRealms.name(rank) + " | Progression rank: " + rank + "/100")
                                        .formatted(Formatting.LIGHT_PURPLE), false);
                                return 1;
                            }))

                    // /btth breakthrough — safe test command, one progression point
                    .then(CommandManager.literal("breakthrough")
                            .executes(context -> {
                                ServerPlayerEntity player = context.getSource().getPlayer();
                                if (player == null) return 0;
                                PlayerFlameData data = FlameDataHelper.get(player);
                                int before = data.getCultivationRank();
                                if (before >= 100) {
                                    context.getSource().sendFeedback(() -> Text.literal("You have reached Dou Di!")
                                            .formatted(Formatting.GOLD), false);
                                    return 1;
                                }
                                FlameDataHelper.modify(player, d -> d.addCultivationRank(1));
                                int after = FlameDataHelper.get(player).getCultivationRank();
                                boolean realmUp = !CultivationRealms.name(before).equals(CultivationRealms.name(after));
                                context.getSource().sendFeedback(() -> Text.literal(realmUp
                                        ? "✦ BREAKTHROUGH! " + CultivationRealms.name(after)
                                        : "Cultivation increased: " + CultivationRealms.name(after))
                                        .formatted(realmUp ? Formatting.GOLD : Formatting.AQUA), false);
                                player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                                        net.minecraft.sound.SoundEvents.BLOCK_BEACON_POWER_SELECT,
                                        net.minecraft.sound.SoundCategory.PLAYERS, 0.8f, realmUp ? 1.3f : 1.0f);
                                return 1;
                            }))

                    // /btth clan — view your saved sect/clan
                    .then(CommandManager.literal("clan")
                            .executes(context -> {
                                ServerPlayerEntity player = context.getSource().getPlayer();
                                if (player == null) return 0;
                                PlayerFlameData data = FlameDataHelper.get(player);
                                String clan = data.getClan().isEmpty() ? "Unaffiliated" : data.getClan();
                                context.getSource().sendFeedback(() -> Text.literal("✦ Clan / Sect: " + clan)
                                        .formatted(Formatting.GOLD), false);
                                return 1;
                            })
                            .then(CommandManager.literal("join")
                                    .then(CommandManager.argument("name", StringArgumentType.word())
                                            .suggests((context, builder) -> {
                                                builder.suggest("xiao");
                                                builder.suggest("yun_lan");
                                                builder.suggest("mitre");
                                                builder.suggest("jia_nan");
                                                return builder.buildFuture();
                                            })
                                            .executes(context -> {
                                                ServerPlayerEntity player = context.getSource().getPlayer();
                                                if (player == null) return 0;
                                                String key = StringArgumentType.getString(context, "name").toLowerCase();
                                                String clan = switch (key) {
                                                    case "xiao" -> "Xiao Clan";
                                                    case "yun_lan" -> "Yun Lan Sect";
                                                    case "mitre" -> "Mite'er Clan";
                                                    case "jia_nan" -> "Jia Nan Academy";
                                                    default -> null;
                                                };
                                                if (clan == null) {
                                                    context.getSource().sendError(Text.literal("Choose: xiao, yun_lan, mitre, or jia_nan"));
                                                    return 0;
                                                }
                                                FlameDataHelper.modify(player, data -> data.setClan(clan));
                                                context.getSource().sendFeedback(() -> Text.literal("✦ You have joined " + clan + "!")
                                                        .formatted(Formatting.GOLD), false);
                                                player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                                                        net.minecraft.sound.SoundEvents.BLOCK_BEACON_ACTIVATE,
                                                        net.minecraft.sound.SoundCategory.PLAYERS, 0.7f, 1.4f);
                                                return 1;
                                            })))
                    )

                    // /btth clearflames
                    .then(CommandManager.literal("clearflames")
                            .executes(context -> {
                                ServerPlayerEntity player = context.getSource().getPlayer();
                                if (player == null) return 0;
                                FlameDataHelper.modify(player, data -> {
                                    data.getRefinedFlames().clear();
                                    // Note: flamePower not fully reset here for simplicity
                                });
                                context.getSource().sendFeedback(() -> Text.literal("Cleared all refined flames"), false);
                                return 1;
                            }))
            );
        });
    }
}
