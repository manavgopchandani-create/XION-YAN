package com.btth.heavenlyflames.component;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;

import java.util.HashSet;
import java.util.Set;

/**
 * Stores a player's refined Heavenly Flames and cultivation rank.
 * Saved into the player's persistent NBT.
 */
public class PlayerFlameData {
    public static final String NBT_KEY = "BtthFlameData";

    private int cultivationRank = 0; // 0 = Mortal / Dou Zhi Qi start
    private final Set<String> refinedFlames = new HashSet<>();
    private int flamePower = 0; // Combined power from refined flames
    private String clan = ""; // Empty means unaffiliated

    public String getClan() { return clan; }

    public void setClan(String clan) { this.clan = clan == null ? "" : clan; }

    public int getCultivationRank() {
        return cultivationRank;
    }

    public void setCultivationRank(int rank) {
        this.cultivationRank = Math.max(0, rank);
    }

    public void addCultivationRank(int amount) {
        this.cultivationRank = Math.max(0, this.cultivationRank + amount);
    }

    public Set<String> getRefinedFlames() {
        return refinedFlames;
    }

    public boolean hasFlame(String flameId) {
        return refinedFlames.contains(flameId);
    }

    public boolean refineFlame(String flameId, int rankPower) {
        if (refinedFlames.contains(flameId)) {
            return false; // Already refined
        }
        refinedFlames.add(flameId);
        flamePower += rankPower;
        // Small cultivation boost on successful refine
        cultivationRank += Math.max(1, (24 - rankPower) / 3);
        return true;
    }

    public int getFlamePower() {
        return flamePower;
    }

    public int getFlameCount() {
        return refinedFlames.size();
    }

    // --- NBT ---
    public NbtCompound writeNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.putInt("CultivationRank", cultivationRank);
        nbt.putInt("FlamePower", flamePower);
        nbt.putString("Clan", clan);

        NbtList list = new NbtList();
        for (String id : refinedFlames) {
            list.add(NbtString.of(id));
        }
        nbt.put("RefinedFlames", list);
        return nbt;
    }

    public void readNbt(NbtCompound nbt) {
        cultivationRank = nbt.getInt("CultivationRank");
        flamePower = nbt.getInt("FlamePower");
        clan = nbt.getString("Clan");
        refinedFlames.clear();

        if (nbt.contains("RefinedFlames", NbtElement.LIST_TYPE)) {
            NbtList list = nbt.getList("RefinedFlames", NbtElement.STRING_TYPE);
            for (int i = 0; i < list.size(); i++) {
                refinedFlames.add(list.getString(i));
            }
        }
    }

    public static PlayerFlameData fromNbt(NbtCompound playerNbt) {
        PlayerFlameData data = new PlayerFlameData();
        if (playerNbt.contains(NBT_KEY, NbtElement.COMPOUND_TYPE)) {
            data.readNbt(playerNbt.getCompound(NBT_KEY));
        }
        return data;
    }

    public void saveToPlayerNbt(NbtCompound playerNbt) {
        playerNbt.put(NBT_KEY, writeNbt());
    }
}
